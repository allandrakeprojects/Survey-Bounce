/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'lv', {
	alt: 'Alternatīvais teksts',
	btnUpload: 'Nosūtīt serverim',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Informācija par attēlu',
	lockRatio: 'Nemainīga Augstuma/Platuma attiecība',
	menu: 'Attēla īpašības',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Atjaunot sākotnējo izmēru',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Attēla īpašības',
	uploadTab: 'Augšupielādēt',
	urlMissing: 'Trūkst attēla atrašanās adrese.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
