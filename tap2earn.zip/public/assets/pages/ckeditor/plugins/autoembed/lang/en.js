/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'en', {
	embeddingInProgress: 'Trying to embed pasted URL...',
	embeddingFailed: 'This URL could not be automatically embedded.'
} );
